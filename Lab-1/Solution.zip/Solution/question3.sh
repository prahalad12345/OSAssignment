grep -h -i $1 $2 | wc -l
