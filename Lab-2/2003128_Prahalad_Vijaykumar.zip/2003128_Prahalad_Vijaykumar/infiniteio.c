#include <stdio.h> 
 

int main(){
    while(1){
        printf("hello");
    }
    return 0;
}